# Precision & Recall Challenge

## Overview

This is an educational web application designed to teach users about machine learning evaluation metrics—specifically precision and recall. The app presents an interactive game where users identify dogs among various animal emojis and calculate precision/recall values based on the model's predictions. Built as a full-stack TypeScript application with React frontend and Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with hot module replacement
- **Styling**: Tailwind CSS with CSS variables for theming
- **UI Components**: Radix UI primitives wrapped with shadcn/ui component library
- **State Management**: Zustand stores for game state (`usePrecisionRecall`, `useGame`, `useAudio`)
- **Data Fetching**: TanStack Query (React Query) for server state management

The frontend follows a component-based architecture with:
- Game screens in `client/src/components/game/` (WelcomeScreen, GameScreen, FeedbackScreen, ResultsScreen)
- Reusable UI primitives in `client/src/components/ui/`
- State stores in `client/src/lib/stores/`

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **HTTP Server**: Node.js native HTTP server wrapping Express
- **Development**: tsx for TypeScript execution, Vite dev server integration
- **Production Build**: esbuild for server bundling, Vite for client bundling

The server follows a modular structure:
- `server/index.ts` - Main entry point with middleware setup
- `server/routes.ts` - API route registration (prefixed with `/api`)
- `server/storage.ts` - Data access layer with storage interface
- `server/vite.ts` - Vite dev server integration for development
- `server/static.ts` - Static file serving for production

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Defined in `shared/schema.ts` using Drizzle's schema builder
- **Validation**: Zod schemas generated from Drizzle schemas via `drizzle-zod`
- **Current Implementation**: In-memory storage (`MemStorage` class) with interface for future database integration
- **Database Ready**: PostgreSQL configuration in `drizzle.config.ts`, requires `DATABASE_URL` environment variable

### Path Aliases
- `@/*` maps to `client/src/*`
- `@shared/*` maps to `shared/*`

## External Dependencies

### Core Services
- **PostgreSQL**: Database (configured but uses in-memory storage until DATABASE_URL is provided)
- **Drizzle Kit**: Database migrations and schema management (`npm run db:push`)

### UI Libraries
- **Radix UI**: Comprehensive set of accessible UI primitives (dialog, dropdown, tabs, etc.)
- **Lucide React**: Icon library
- **React Three Fiber/Drei**: 3D graphics capabilities (included but not actively used in current game)
- **Embla Carousel**: Carousel component
- **React Day Picker**: Calendar component
- **Recharts**: Charting library

### Build & Development
- **Vite**: Frontend build tool with React plugin, GLSL shader support, and runtime error overlay
- **esbuild**: Server-side bundling for production
- **PostCSS/Autoprefixer**: CSS processing
- **TypeScript**: Type checking with strict mode

### Session & Authentication (Available)
- `connect-pg-simple`: PostgreSQL session store
- `express-session`: Session management
- `passport` / `passport-local`: Authentication framework